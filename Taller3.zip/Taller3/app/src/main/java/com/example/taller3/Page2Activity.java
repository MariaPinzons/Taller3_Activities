package com.example.taller3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Page2Activity extends AppCompatActivity {

    Button calcular;
    private EditText et1;
    private EditText et2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        et1=(EditText)findViewById(R.id.txt_codigo);//codigo editar texto
        et2=(EditText)findViewById(R.id.txt_email);//codigo editar texto

        //codigo para la creacion del boton
        calcular=(Button)findViewById(R.id.btn_ventana3);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(Page2Activity.this, Page3Activity.class);
                startActivity(i);
                //codigo para la creacion del boton

            }
        });
    }
    //Metodo para el boton enviar
    public void Enviar(View view)
    {
        Intent i = new Intent(this, Page3Activity.class);
        i.putExtra("dato1",et1.getText().toString());
        i.putExtra("dato2",et2.getText().toString());
        startActivity(i);
    }
}