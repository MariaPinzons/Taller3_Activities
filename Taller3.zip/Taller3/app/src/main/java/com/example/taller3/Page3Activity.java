package com.example.taller3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Page3Activity extends AppCompatActivity {

    private TextView tv1;
    private TextView tv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page3);

        tv1=(TextView) findViewById(R.id.txtView_codigo);
        tv2=(TextView) findViewById(R.id.txtView_correo);

        String dato1 = getIntent().getStringExtra("dato1");
        tv1.setText(dato1);

        String dato2 = getIntent().getStringExtra("dato2");
        tv2.setText(dato2);

    }

    //Metodo boton regresar

    public void Regresar(View view)
    {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

}